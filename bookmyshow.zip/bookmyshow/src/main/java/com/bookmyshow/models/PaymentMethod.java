package com.bookmyshow.models;

public class PaymentMethod {

}
