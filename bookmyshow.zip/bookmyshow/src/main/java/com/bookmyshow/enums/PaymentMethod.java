package com.bookmyshow.enums;

public enum PaymentMethod {
    CARD,
    UPI,
    NET_BANKING,
    WALLET
}
