package com.bookmyshow.enums;

public enum PaymentStatus {
    SUCCESS,
    FAILED,
    PENDING,
    CANCELLED
}
