package com.bookmyshow.enums;

public enum SeatType {
    REGULAR,
    PREMIUM,
    RECLINER,
    VIP
}
