package com.bookmyshow.enums;

public enum BookingStatus {
    PENDING, 
    CONFIRMED, 
    CANCELLED
}